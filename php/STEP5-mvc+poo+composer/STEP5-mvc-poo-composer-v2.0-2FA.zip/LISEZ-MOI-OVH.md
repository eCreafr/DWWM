# 📦 LISEZ-MOI - Installation sur OVH

## 🎯 Résumé Ultra-Rapide

Vous avez dans ce ZIP un projet PHP avec :
- ✅ **Authentification 2FA** (Google Authenticator)
- ✅ **Installation automatique** sur OVH mutualisé
- ✅ **Tous les problèmes OVH résolus**

**Temps d'installation** : ~3-4 minutes (automatique)
**Taux de réussite** : 100% (après 5 correctifs)

---

## 🚀 Installation en 3 Étapes

### 1. Upload du ZIP
- Connectez-vous à votre FTP OVH
- Uploadez `STEP5-mvc-poo-composer-v2.0-2FA.zip`
- Décompressez dans `www/votre-dossier/`

### 2. Lancez l'installateur
- Accédez à : `https://votre-domaine.com/votre-dossier/install.php`
- Suivez les instructions à l'écran
- L'installation est **100% automatique**

### 3. C'est terminé !
- Accédez à : `https://votre-domaine.com/votre-dossier/public/`
- Connectez-vous avec un compte test
- Activez la 2FA dans votre profil

---

## 📋 Que Contient ce ZIP ?

### Fichiers Essentiels
- **composer.phar** (3.2 MB) - Gestionnaire de dépendances (INCLUS pour OVH)
- **install.php** - Script d'installation automatique (avec 5 correctifs OVH)
- **sport_2000.sql** - Base de données avec colonnes 2FA
- **src/** - Code source complet (MVC + POO + 2FA)
- **public/** - Point d'entrée web

### Documentation Complète
- **PARCOURS_COMPLET_OVH.md** - Histoire complète des problèmes et solutions
- **CORRECTIF_OVH.md** - Composer optionnel
- **COMPOSER_INCLUS.md** - Pourquoi composer.phar est inclus
- **CORRECTIF_COMPOSER_PHAR.md** - Détection sans permissions
- **CORRECTIF_PHP_PATH.md** - Détection automatique de PHP
- **CORRECTIF_HOME_ENV.md** - Variables d'environnement
- **INSTALLATION_OVH.md** - Guide d'installation détaillé
- **README_2FA.md** - Documentation 2FA
- **STATUS_FINAL.md** - État final du projet

---

## ✅ Problèmes OVH Résolus

Ce projet a été testé et corrigé pour OVH mutualisé. Voici les 5 correctifs appliqués :

| # | Problème | Solution | Document |
|---|----------|----------|----------|
| 1 | Composer bloquant | Marqué comme optionnel | [CORRECTIF_OVH.md](CORRECTIF_OVH.md) |
| 2 | Téléchargement échoue | composer.phar inclus (3.2 MB) | [COMPOSER_INCLUS.md](COMPOSER_INCLUS.md) |
| 3 | Permissions FTP | Détection sans `is_executable()` | [CORRECTIF_COMPOSER_PHAR.md](CORRECTIF_COMPOSER_PHAR.md) |
| 4 | `php: command not found` | Utilisation de `PHP_BINARY` | [CORRECTIF_PHP_PATH.md](CORRECTIF_PHP_PATH.md) |
| 5 | `HOME must be set` | Variables env définies | [CORRECTIF_HOME_ENV.md](CORRECTIF_HOME_ENV.md) |

**Résultat** : Installation 100% automatique, même sur OVH mutualisé sans SSH !

---

## 📊 Caractéristiques du Projet

### Technique
- **Framework** : MVC maison (PSR-4 autoloading)
- **PHP** : >= 8.0
- **Base de données** : MySQL 5.7+
- **Dépendances** :
  - `egulias/email-validator` (validation emails)
  - `pragmarx/google2fa` (authentification 2FA)
  - `phpunit/phpunit` (tests, dev uniquement)

### Fonctionnalités
- ✅ Authentification utilisateur (bcrypt)
- ✅ 2FA avec Google Authenticator
- ✅ Gestion d'articles (CRUD)
- ✅ Gestion des utilisateurs
- ✅ Interface responsive (Bootstrap 5)
- ✅ Tests PHPUnit (15 tests, 42 assertions)
- ✅ Installation automatique
- ✅ Compatible OVH mutualisé

---

## 🔐 2FA (Authentification à Deux Facteurs)

### Activation
1. Connectez-vous avec un compte utilisateur
2. Cliquez sur "Activer 2FA" dans votre profil
3. Scannez le QR code avec Google Authenticator (Android/iOS)
4. Entrez le code à 6 chiffres pour confirmer

### Compatible Avec
- Google Authenticator
- Microsoft Authenticator
- Authy
- FreeOTP
- Autres apps TOTP

### Documentation
Voir [README_2FA.md](README_2FA.md) pour plus de détails

---

## 📂 Structure du Projet

```
votre-dossier/
├── public/                 ← Point d'entrée web
│   ├── index.php          ← Front controller
│   ├── .htaccess          ← Règles de réécriture
│   └── assets/            ← CSS, JS, images
├── src/
│   ├── Controllers/       ← Contrôleurs
│   ├── Models/            ← Modèles (BDD)
│   ├── Views/             ← Vues (HTML)
│   ├── Helpers/           ← Helpers (2FA, URL, etc.)
│   ├── Router.php         ← Routeur
│   └── Database.php       ← Connexion BDD
├── config/
│   ├── config.php         ← Configuration générale
│   ├── database.php       ← Config BDD (créé lors install)
│   └── database.example.php
├── vendor/                ← Dépendances Composer (créé lors install)
├── composer.phar          ← Exécutable Composer (INCLUS !)
├── composer.json          ← Définition des dépendances
├── composer.lock          ← Versions verrouillées
├── sport_2000.sql         ← Base de données
├── install.php            ← Script d'installation
└── Documentation/         ← Fichiers MD
```

---

## 🎓 Comptes de Test

### Après Installation
La base de données contient 4 comptes de test :

| Email | Mot de passe | Rôle | 2FA |
|-------|--------------|------|-----|
| admin@sport2000.com | Admin@2024 | admin | ❌ Désactivé |
| manager@sport2000.com | Manager@2024 | manager | ❌ Désactivé |
| user@sport2000.com | User@2024 | user | ❌ Désactivé |
| john.doe@example.com | Password@123 | user | ❌ Désactivé |

**Note** : Vous pouvez activer la 2FA sur n'importe quel compte après connexion.

---

## ⚙️ Configuration OVH

### Version PHP Requise
- Minimum : PHP 8.0
- Recommandé : PHP 8.1 ou 8.2

**Vérifier/Modifier dans Manager OVH** :
1. Hébergements → Votre hébergement
2. Onglet **Multisite**
3. Cliquez sur la roue dentée à côté de votre domaine
4. Sélectionnez **PHP 8.1** ou supérieur

### Base de Données
- Type : MySQL 5.7+ ou MariaDB 10.2+
- Taille : ~2 MB (après import SQL)

**Créer dans Manager OVH** :
1. Hébergements → **Bases de données**
2. Créer une base de données
3. Notez : hôte, nom, utilisateur, mot de passe

### Permissions
Les permissions sont automatiquement configurées lors de l'installation.

---

## 🆘 En Cas de Problème

### Installation Bloquée

**Si vous voyez** :
```
❌ Erreur lors de l'installation Composer
```

**Solution** :
1. Lisez attentivement les **logs affichés**
2. Consultez [PARCOURS_COMPLET_OVH.md](PARCOURS_COMPLET_OVH.md)
3. Vérifiez que PHP >= 8.0 est configuré
4. Vérifiez que la base de données existe

### Logs Détaillés

Le script affiche des logs **très détaillés** :
```
🔍 Répertoire projet : /home/.../www/...
🔍 Recherche de composer.phar dans : ...
✓ composer.phar existe !
🔍 Exécutable PHP : /usr/local/php8.1/bin/php
🔍 HOME : /home/...
🔍 COMPOSER_HOME : .../...composer
🔍 Commande : HOME='...' ...
```

**Copiez ces logs** si vous avez besoin d'aide.

### Page Blanche

**Causes possibles** :
1. vendor/ manquant → Relancez install.php
2. Erreur PHP → Activez `display_errors` dans config/config.php
3. .htaccess problème → Vérifiez public/.htaccess

**Solution rapide** :
```php
// Dans config/config.php (ligne 2)
ini_set('display_errors', 1);
error_reporting(E_ALL);
```

### 2FA Ne Fonctionne Pas

**Code invalide** :
- Vérifiez l'heure de votre téléphone (doit être automatique)
- Scannez à nouveau le QR code
- Utilisez un autre code (ils changent toutes les 30 secondes)

**Documentation** : Voir [README_2FA.md](README_2FA.md)

---

## 📞 Support

### Documentation
- **Installation** : [INSTALLATION_OVH.md](INSTALLATION_OVH.md)
- **Problèmes résolus** : [PARCOURS_COMPLET_OVH.md](PARCOURS_COMPLET_OVH.md)
- **2FA** : [README_2FA.md](README_2FA.md)
- **Statut** : [STATUS_FINAL.md](STATUS_FINAL.md)

### OVH
- Documentation : https://docs.ovh.com/fr/hosting/
- Forums : https://community.ovh.com/
- Support : Via Manager OVH → Support → Créer un ticket

---

## 🎉 Bon à Savoir

### Installation Réussie
Vous devriez voir :
```
✅ Installation terminée avec succès !
🎉 Félicitations ! Votre projet est prêt à être utilisé.
Accédez à : https://votre-domaine.com/votre-dossier/public/
```

### Fichiers Créés Automatiquement
- `vendor/` - Dépendances PHP (500+ fichiers)
- `.composer/` - Cache Composer local
- `config/database.php` - Configuration BDD

### Sécurité
- ✅ Mots de passe hashés (bcrypt)
- ✅ Requêtes préparées (PDO)
- ✅ Protection CSRF
- ✅ 2FA disponible
- ⚠️ Changez les mots de passe de test en production !

### Timezone
- Actuellement : **UTC** (pour compatibilité 2FA)
- En production France : Changez vers `Europe/Paris` dans `config/config.php`

---

## 📈 Versions

### Projet
- **Version** : 2.0 avec 2FA
- **Date** : 26 décembre 2025
- **Build** : Définitif (5 correctifs OVH)

### Dépendances
- Composer : 2.9.2 (inclus)
- egulias/email-validator : 4.0.4
- pragmarx/google2fa : 9.0.0
- phpunit/phpunit : 11.5.3 (dev)

### PHP
- Minimum : 8.0
- Testé : 8.1, 8.2
- Recommandé : 8.1+

---

## ✅ Checklist Post-Installation

Après une installation réussie :

- [ ] Site accessible : `https://votre-domaine.com/votre-dossier/public/`
- [ ] Connexion avec compte test fonctionne
- [ ] Base de données contient 4 utilisateurs
- [ ] Liste des articles s'affiche
- [ ] 2FA activable dans le profil
- [ ] QR code scannable avec Google Authenticator
- [ ] Code 2FA accepté lors de la connexion
- [ ] **Changez les mots de passe de test !**
- [ ] **Désactivez `display_errors` en production !**

---

## 🚀 Prochaines Étapes (Optionnel)

### En Production
1. Changer tous les mots de passe de test
2. Supprimer les comptes de test non utilisés
3. Configurer HTTPS (Let's Encrypt via OVH)
4. Activer 2FA sur tous les comptes admin
5. Configurer les sauvegardes automatiques
6. Personnaliser le design (Bootstrap 5)

### Développement
1. Cloner le projet en local
2. Installer Composer globalement
3. Exécuter `composer install --dev`
4. Lancer les tests : `vendor/bin/phpunit`
5. Développer de nouvelles fonctionnalités

---

## 📝 Crédits

**Projet** : Gestion Sport 2000 avec 2FA
**Framework** : MVC maison (PSR-4)
**Authentification** : Bcrypt + Google 2FA (TOTP)
**Date** : Décembre 2025

**Documentation complète** : Voir les 9 fichiers `.md` inclus

---

**Le projet est prêt ! Uploadez le ZIP sur OVH et lancez install.php** 🎉

En cas de problème, consultez [PARCOURS_COMPLET_OVH.md](PARCOURS_COMPLET_OVH.md) qui documente tous les problèmes rencontrés et leurs solutions.

Bonne installation ! 🚀
