# Installation sur serveur OVH

## 🌐 Guide d'installation pour hébergement mutualisé OVH

Ce guide explique comment installer le projet sur un serveur OVH (ou autre hébergement mutualisé).

---

## 📋 Prérequis

-   Hébergement OVH avec PHP 8.0 minimum
-   Accès FTP (FileZilla, Cyberduck, etc.)
-   Accès phpMyAdmin
-   Base de données MySQL créée

---

## 🚀 Méthode 1 : Installation automatique (recommandée)

### Étape 1 : Upload des fichiers

1. Décompressez `STEP5-mvc-poo-composer-v2.0-2FA.zip` sur votre ordinateur
2. Connectez-vous en FTP à votre hébergement OVH
3. Uploadez **tous les fichiers** dans le dossier `www/` (ou `public_html/`)

### Étape 2 : Lancer l'installation

1. Accédez à : `https://votre-domaine.com/install.php`
2. Suivez les étapes à l'écran

**Important** : Le script téléchargera automatiquement Composer s'il n'est pas trouvé !

---

## 🔧 Méthode 2 : Installation manuelle

Si l'installation automatique échoue, suivez ces étapes :

### Étape 1 : Créer la base de données

1. Connectez-vous à votre **Manager OVH**
2. Section **Hébergements** → **Bases de données**
3. Créez une nouvelle base MySQL
4. Notez les informations :
    - Hôte (ex: `mysql51-xx.perso`)
    - Nom de la base
    - Utilisateur
    - Mot de passe

### Étape 2 : Configuration de la base

1. En FTP, allez dans `config/`
2. Copiez `database.example.php` → `database.php`
3. Éditez `database.php` avec vos informations OVH

```php
return [
    'host' => 'mysql51-xx.perso',  // Hôte fourni par OVH
    'dbname' => 'votre_base',      // Nom de votre base
    'username' => 'votre_user',    // Utilisateur OVH
    'password' => 'votre_mdp',     // Mot de passe
    'charset' => 'utf8',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];
```

### Étape 3 : Import de la base de données

1. Accédez à **phpMyAdmin** depuis votre Manager OVH
2. Sélectionnez votre base de données
3. Onglet **Importer**
4. Choisissez le fichier `sport_2000.sql`
5. Cliquez sur **Exécuter**

### Étape 4 : Installation de Composer (via SSH)

**Si vous avez un accès SSH** (hébergement Pro ou supérieur) :

```bash
# Se connecter en SSH
ssh votre_user@ssh.cluster0XX.hosting.ovh.net

# Aller dans le dossier www
cd www/STEP5

# Télécharger Composer
curl -sS https://getcomposer.org/installer | php

# Installer les dépendances
php composer.phar install --no-dev --optimize-autoloader
```

**Si vous N'avez PAS accès SSH** :

1. Sur votre ordinateur local (avec Composer installé) :

    ```bash
    composer install --no-dev --optimize-autoloader
    ```

2. Uploadez le dossier `vendor/` complet via FTP
   ⚠️ Attention : 500+ fichiers, peut prendre du temps !

### Étape 5 : Configuration du .htaccess

Vérifiez que le fichier `public/.htaccess` est bien uploadé.

Si besoin, créez-le avec ce contenu :

```apache
RewriteEngine On

# Bloque l'accès direct aux dossiers sensibles
RewriteRule ^(config|src)/.*$ - [F,L]

# URLs des articles : articles/123-titre.html
RewriteRule ^articles/([0-9]+)-([a-zA-Z0-9-]+)\.html$ index.php?page=articles&id=$1 [L,QSA]

# Règle générale : page.html → index.php?page=page
RewriteRule ^(.*)\.html$ index.php?page=$1 [L,QSA]
```

### Étape 6 : Permissions des fichiers

```bash
# Via SSH ou FTP, définir les permissions
chmod 755 public/assets/img/articles
chmod 644 config/database.php
chmod 644 public/.htaccess
```

### Étape 7 : Tester l'installation

Accédez à : `https://votre-domaine.com/public/`

---

## ⚠️ Problèmes courants sur OVH

### 1. Erreur "Composer not found"

**Solution A** : Le script téléchargera Composer automatiquement

**Solution B** : Télécharger manuellement

```bash
# Via SSH
cd www/STEP5
curl -sS https://getcomposer.org/installer | php
```

**Solution C** : Uploader vendor/ depuis votre machine locale

### 2. Erreur "PDO connection failed"

**Causes** :

-   Mauvaises informations de connexion
-   Base de données non créée
-   Hôte incorrect

**Solution** :

1. Vérifiez `config/database.php`
2. Vérifiez le nom d'hôte dans Manager OVH
3. Vérifiez que la base existe

### 3. Erreur 500 - Internal Server Error

**Causes** :

-   Erreur PHP
-   .htaccess incorrect
-   Vendor non installé

**Solution** :

1. Activez l'affichage des erreurs dans `config/config.php` :

    ```php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
    ```

2. Consultez les logs dans Manager OVH → Logs

### 4. Images ne s'affichent pas

**Solution** :

```bash
chmod 755 public/assets/img/articles
```

### 5. Page blanche

**Causes** :

-   vendor/ manquant
-   Erreur fatale PHP

**Solution** :

1. Vérifiez que `vendor/` existe
2. Consultez les logs OVH
3. Vérifiez PHP >= 8.0

---

## 🔐 Sécurité sur OVH

### Protéger config/database.php

Ajoutez dans `public/.htaccess` :

```apache
# Bloque l'accès aux fichiers sensibles
<FilesMatch "^(database\.php|composer\.(json|lock))$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

### HTTPS obligatoire

Dans `config/config.php`, forcez HTTPS :

```php
// Force HTTPS
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit;
}
```

### Désactiver display_errors en production

Dans `config/config.php` :

```php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);
```

---

## 📊 Structure des dossiers OVH

```
/home/votre_user/
└── www/
    └── STEP5/                  ← Racine du projet
        ├── public/             ← Point d'entrée web
        │   ├── index.php
        │   ├── .htaccess       ← IMPORTANT !
        │   └── assets/
        ├── src/
        ├── config/
        │   └── database.php    ← À créer/éditer
        ├── vendor/             ← À installer
        ├── composer.json
        └── sport_2000.sql
```

**URL d'accès** : `https://votre-domaine.com/STEP5/public/`

### Configurer l'URL racine

Pour accéder directement via `https://votre-domaine.com/` :

1. Déplacez le contenu de `public/` à la racine `www/`
2. Ajustez les chemins dans `index.php`

---

## 🎯 Checklist d'installation OVH

-   [ ] Fichiers uploadés via FTP
-   [ ] Base de données créée dans Manager OVH
-   [ ] `config/database.php` configuré
-   [ ] `sport_2000.sql` importé via phpMyAdmin
-   [ ] Composer installé (ou vendor/ uploadé)
-   [ ] `public/.htaccess` présent
-   [ ] Permissions définies (755 pour dossiers, 644 pour fichiers)
-   [ ] Test : accès à `https://votre-domaine.com/STEP5/public/`
-   [ ] Connexion avec compte test fonctionne
-   [ ] 2FA testable (optionnel)

---

## 💡 Optimisations OVH

### Cache OPcache

OVH active OPcache par défaut. Pour vider le cache après mise à jour :

```php
// clear_cache.php
<?php
if (function_exists('opcache_reset')) {
    opcache_reset();
    echo 'Cache OPcache vidé !';
}
```

### Compression Gzip

Ajoutez dans `public/.htaccess` :

```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript
</IfModule>
```

---

## 🆘 Support OVH

**Documentation OVH** :

-   https://docs.ovh.com/fr/hosting/

**Forums** :

-   https://community.ovh.com/

**Support technique** :

-   Via Manager OVH → Support

---

## 📝 Notes importantes

1. **Version PHP** : Vérifiez dans Manager OVH que PHP >= 8.0 est activé
2. **Limite mémoire** : OVH limite à 128-256 MB (suffisant pour ce projet)
3. **Temps d'exécution** : Limitié à 30-60 secondes (l'install peut être lent)
4. **Cron jobs** : Disponibles pour tâches planifiées si nécessaire

---

**Votre projet devrait maintenant fonctionner sur OVH ! 🎉**

Si vous rencontrez des problèmes, consultez les logs OVH ou contactez leur support.
