# Solution au problème Composer sur OVH

## 🐛 Problème rencontré

```
sh: /home/ecrea/www/STEP5/composer.phar: No such file or directory
```

**Cause** : Composer n'est pas installé sur le serveur OVH mutualisé.

---

## ✅ Solutions implémentées

### 1. Téléchargement automatique de Composer

Le script `install.php` a été amélioré pour **télécharger automatiquement Composer** s'il n'est pas trouvé.

**Modifications dans [install.php](install.php)** :

#### Méthode `findComposer()` améliorée (ligne 350)
Cherche Composer dans plus d'emplacements :
- `PROJECT_ROOT/composer.phar` (local au projet)
- `composer` (commande globale)
- `/usr/local/bin/composer` (Linux)
- `/usr/bin/composer` (Linux)
- `$HOME/.composer/composer.phar` (utilisateur)

#### Nouvelle méthode `downloadComposer()` (ligne 382)
Télécharge et installe Composer automatiquement :
1. Télécharge le script d'installation depuis `https://getcomposer.org/installer`
2. Exécute l'installation
3. Place `composer.phar` dans la racine du projet
4. Définit les permissions (chmod 755)

#### Méthode `installComposerDependencies()` modifiée (ligne 157)
Logique améliorée :
1. Cherche Composer
2. **Si non trouvé** → télécharge automatiquement
3. Re-cherche après téléchargement
4. Exécute `composer install`

---

## 🚀 Comment ça fonctionne maintenant

### Sur OVH (ou autre hébergement sans Composer)

1. **Upload du projet** via FTP
2. **Accès à** `https://votre-domaine.com/install.php`
3. **Le script détecte** que Composer manque
4. **Téléchargement automatique** de Composer
5. **Installation des dépendances** (vendor/)
6. **Projet fonctionnel** ! 🎉

### Logs affichés

```
📦 Installation des dépendances Composer...
⚠️  Composer non trouvé sur le système
📥 Téléchargement de Composer...
✅ Composer téléchargé avec succès
✓ Composer trouvé : /home/ecrea/www/STEP5/composer.phar
✅ Dépendances Composer installées avec succès !
   - egulias/email-validator
   - pragmarx/google2fa (2FA)
   - phpunit/phpunit
```

---

## 📋 Solutions alternatives (si le téléchargement échoue)

### Option A : Installation manuelle de Composer (via SSH)

Si vous avez accès SSH :

```bash
# Se connecter en SSH
ssh votre_user@ssh.cluster0XX.hosting.ovh.net

# Aller dans le dossier du projet
cd www/STEP5

# Télécharger Composer
curl -sS https://getcomposer.org/installer | php

# Installer les dépendances
php composer.phar install --no-dev --optimize-autoloader
```

### Option B : Upload du dossier vendor/

Si pas d'accès SSH et téléchargement impossible :

1. **Sur votre machine locale** (avec Composer installé) :
   ```bash
   cd STEP5-mvc+poo+composer
   composer install --no-dev --optimize-autoloader
   ```

2. **Upload du dossier vendor/** complet via FTP
   - ⚠️ Attention : 500+ fichiers, peut prendre 10-20 minutes
   - Taille : ~10 MB

3. **Continuer l'installation** normalement

### Option C : Hébergement avec Composer préinstallé

Certains hébergeurs incluent Composer :
- **o2switch** : Composer préinstallé
- **Hostinger** : Composer disponible
- **Infomaniak** : Composer disponible
- **OVH Pro+** : Composer accessible via SSH

---

## 🔧 Configuration OVH spécifique

### Vérifier la version PHP

Dans **Manager OVH** :
1. Hébergements → Votre hébergement
2. **Multisite** → Configuration
3. Vérifier **PHP 8.0+** est activé

### Permissions nécessaires

```bash
chmod 755 public/assets/img/articles
chmod 644 config/database.php
chmod 755 composer.phar  # Si téléchargé manuellement
```

### Limites OVH à connaître

| Paramètre | Limite OVH |
|-----------|------------|
| Mémoire PHP | 128-256 MB |
| Temps d'exécution | 30-60 sec |
| Upload max | 20-100 MB |
| Fonctions désactivées | `exec()`, `shell_exec()` parfois |

⚠️ **Important** : Si `exec()` est désactivé, le téléchargement auto de Composer ne fonctionnera pas.
→ Utilisez l'**Option B** (upload vendor/)

---

## 📝 Nouveaux fichiers créés

1. **[INSTALLATION_OVH.md](INSTALLATION_OVH.md)** - Guide complet pour OVH
2. **[SOLUTION_OVH.md](SOLUTION_OVH.md)** - Ce fichier
3. **[install.php](install.php)** - Amélioré avec téléchargement auto

---

## 🎯 Checklist rapide OVH

- [ ] Fichiers uploadés via FTP
- [ ] Accès à `install.php`
- [ ] Composer téléchargé automatiquement
- [ ] OU Composer installé manuellement (SSH)
- [ ] OU vendor/ uploadé manuellement (FTP)
- [ ] Base de données importée
- [ ] Site accessible et fonctionnel

---

## 🆘 Si ça ne fonctionne toujours pas

### Diagnostic

1. **Vérifier que PHP >= 8.0**
   - Manager OVH → Hébergement → Multisite

2. **Vérifier les logs**
   - Manager OVH → Plus+ → Statistiques et logs

3. **Tester exec()**
   ```php
   <?php
   exec('ls -la', $output, $code);
   echo "Code: $code<br>";
   print_r($output);
   ```

4. **Contacter le support OVH**
   - Via Manager OVH → Support → Créer un ticket

---

## 💡 Recommandations

### Pour le développement

Utilisez **WAMP/XAMPP** en local avec Composer installé.

### Pour la production

- **OVH Pro** ou supérieur (accès SSH + Composer)
- Ou hébergeur avec Composer préinstallé
- Ou upload vendor/ systématique

### Pour les mises à jour

```bash
# En local
composer update
git add vendor/
git push

# Sur OVH via FTP
# Upload vendor/ complet
```

---

**Le projet devrait maintenant s'installer sans problème sur OVH ! 🎉**

Consultez [INSTALLATION_OVH.md](INSTALLATION_OVH.md) pour le guide détaillé.
