<?php
/**
 * Configuration de la base de données
 *
 * INSTRUCTIONS:
 * 1. Renommez ce fichier en 'database.php'
 * 2. Modifiez les valeurs ci-dessous selon votre configuration
 */

return [
    'host' => 'localhost',
    'dbname' => 'sport_2000',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];
