# 🚀 Installation Automatique - Projet MVC PHP

## Présentation

Ce projet MVC PHP comprend un système d'installation automatique DevOps qui configure automatiquement l'ensemble de l'environnement.

### Fonctionnalités du Script d'Installation

✅ Vérification automatique des prérequis système
✅ Installation des dépendances Composer (Egulias, PHPUnit)
✅ Import automatique de la base de données MySQL
✅ Exécution de la suite de tests PHPUnit (92 tests, 147 assertions)
✅ Nettoyage automatique des fichiers d'installation
✅ Interface web intuitive avec indicateurs de progression

---

## Prérequis

Avant de lancer l'installation, assurez-vous d'avoir :

- **PHP >= 8.0** avec les extensions :
  - PDO
  - PDO MySQL
- **MySQL ou MariaDB**
- **Composer** installé globalement ou localement
- **Serveur web** (Apache, Nginx) ou PHP Built-in Server

---

## Installation

### Méthode 1 : Installation via Interface Web (Recommandée)

1. **Décompressez le projet** dans votre répertoire web :
   ```bash
   unzip projet-mvc-php.zip -d /var/www/html/projet-mvc-php
   # ou sous Windows avec XAMPP/WAMP
   unzip projet-mvc-php.zip -d C:\xampp\htdocs\projet-mvc-php
   ```

2. **Accédez au script d'installation** via votre navigateur :
   ```
   http://localhost/projet-mvc-php/install.php
   ```

3. **Suivez les 5 étapes de l'installation** :

   **Étape 1 : Vérification des Prérequis**
   - Cliquez sur "Démarrer l'installation"
   - Le script vérifie PHP, PDO, Composer, fichiers requis

   **Étape 2 : Installation des Dépendances**
   - Cliquez sur "Installer les dépendances Composer"
   - Installe egulias/email-validator et phpunit/phpunit

   **Étape 3 : Configuration de la Base de Données**
   - Renseignez vos identifiants MySQL :
     - Hôte : `localhost`
     - Nom de la base : `sport_2000`
     - Utilisateur : `root`
     - Mot de passe : (votre mot de passe MySQL)
   - Cliquez sur "Importer la base de données"

   **Étape 4 : Exécution des Tests**
   - Cliquez sur "Exécuter les tests PHPUnit"
   - Vérifiez que tous les tests passent (92 tests, 147 assertions)

   **Étape 5 : Nettoyage**
   - Cliquez sur "Finaliser l'installation"
   - Les fichiers d'installation sont supprimés automatiquement

4. **Accédez au site** :
   - Cliquez sur "🏠 Accéder au site"
   - L'installation est terminée !

---

### Méthode 2 : Installation Manuelle

Si vous préférez installer manuellement :

```bash
# 1. Installer les dépendances Composer
composer install

# 2. Créer la base de données et importer le SQL
mysql -u root -p
CREATE DATABASE sport_2000 CHARACTER SET utf8 COLLATE utf8_general_ci;
USE sport_2000;
SOURCE sport_2000.sql;
EXIT;

# 3. Configurer la connexion à la base
# Créer config/database.php avec vos identifiants

# 4. Lancer les tests (optionnel)
composer test

# 5. Supprimer les fichiers d'installation
rm install.php install-ui.php sport_2000.sql
```

---

## Configuration Post-Installation

### Comptes Utilisateur par Défaut

La base de données `sport_2000` contient des comptes de test :

| Email | Mot de passe | Rôle |
|-------|--------------|------|
| admin@sport2000.com | 123 | ADMIN |
| user@sport2000.com | 123 | USER |

### Structure de la Base de Données

- **Table `users`** : Gestion des utilisateurs (id, name, email, pswd, role)
- **Table `s2_articles_presse`** : Articles de presse sportive
- **Table `s2_resultats_sportifs`** : Résultats sportifs

---

## Fonctionnalités du Projet

### 🔐 Système d'Authentification
- Connexion / Déconnexion
- Inscription avec validation email (Egulias)
- Gestion des rôles (ADMIN / USER)

### 📰 Gestion d'Articles
- Liste des articles avec pagination
- Affichage détaillé des articles
- Administration réservée aux ADMIN

### 🧪 Suite de Tests PHPUnit
- **92 tests** couvrant :
  - Helpers (EmailValidator, StringHelper, UrlHelper, AuthHelper)
  - Models (User, Article)
  - Integration (Router, Security)
- **147 assertions**
- Interface web pour exécuter les tests : `http://localhost/projet-mvc-php/public/tests.html`

### 📧 Validation Email avec Egulias
- Validation RFC stricte
- Vérification DNS
- Vérification des enregistrements MX

---

## Commandes Utiles

```bash
# Lancer les tests PHPUnit
composer test

# Lancer les tests avec coverage HTML
composer test:coverage

# Vérifier la version de Composer
composer --version

# Mettre à jour les dépendances
composer update

# Lancer le serveur PHP intégré
php -S localhost:8000 -t public/
```

---

## Résolution de Problèmes

### Erreur : "Composer non trouvé"
```bash
# Installer Composer globalement
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer

# Ou télécharger composer.phar dans le dossier du projet
```

### Erreur : "PDO extension not loaded"
```bash
# Sous Ubuntu/Debian
sudo apt install php-pdo php-mysql

# Sous Windows (php.ini)
# Décommenter : extension=pdo_mysql
```

### Erreur : "Access denied for user"
Vérifiez vos identifiants MySQL dans `config/database.php`

### Tests PHPUnit échouent
- Vérifiez que la base de données est bien importée
- Vérifiez que Composer a installé toutes les dépendances

---

## Architecture du Projet

```
projet-mvc-php/
├── config/
│   └── database.php         # Configuration BDD (généré par install)
├── public/
│   ├── index.php            # Point d'entrée principal
│   └── assets/              # CSS, JS, images
├── src/
│   ├── Controllers/         # Contrôleurs MVC
│   ├── Models/              # Modèles MVC
│   ├── Views/               # Vues MVC
│   ├── Helpers/             # Classes utilitaires
│   ├── Router.php           # Routeur principal
│   └── Database.php         # Singleton PDO
├── tests/                   # Suite de tests PHPUnit
├── vendor/                  # Dépendances Composer
├── composer.json            # Configuration Composer
├── phpunit.xml              # Configuration PHPUnit
├── install.php              # Script d'installation
└── sport_2000.sql           # Export BDD
```

---

## Technologies Utilisées

- **PHP 8.0+** : Langage backend
- **MySQL** : Base de données
- **Composer** : Gestionnaire de dépendances
- **PHPUnit 12.5** : Framework de tests
- **Egulias Email Validator** : Validation d'emails
- **Bootstrap 5** : Framework CSS
- **PSR-4** : Autoloading standard

---

## Support

Pour toute question ou problème :
1. Vérifiez les logs d'erreur PHP
2. Consultez la documentation PHPUnit : https://phpunit.de/
3. Consultez la documentation Egulias : https://github.com/egulias/EmailValidator

---

## Licence

Projet pédagogique - Formation MVC PHP + POO + Composer
