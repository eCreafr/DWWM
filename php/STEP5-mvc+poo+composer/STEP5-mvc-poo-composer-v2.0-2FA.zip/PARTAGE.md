# Guide de partage du projet

## 📦 Fichier à partager

**Fichier créé** : `STEP5-mvc-poo-composer-v2.0-2FA.zip` (240 KB)

## ✅ Ce qui EST inclus dans le ZIP

### Fichiers essentiels
- ✅ Tous les fichiers source PHP (`src/`)
- ✅ Vues, contrôleurs, modèles, helpers
- ✅ Configuration publique (`public/`)
- ✅ Assets (CSS, JS, images de base)
- ✅ Fichier SQL : `sport_2000.sql` (avec colonnes 2FA)
- ✅ Scripts d'installation : `install.php`, `install-ui.php`
- ✅ Configuration Composer : `composer.json`, `composer.lock`
- ✅ Configuration PHPUnit : `phpunit.xml`
- ✅ Tests unitaires : `tests/`

### Documentation
- ✅ `README.md` - Documentation principale
- ✅ `README_2FA.md` - Documentation 2FA
- ✅ `INSTALLATION_2FA.md` - Guide d'installation 2FA
- ✅ `CHANGELOG_2FA.md` - Historique des modifications
- ✅ `INSTALLATION.txt` - Guide rapide (dans le ZIP)

### Configuration
- ✅ `config/database.example.php` - Exemple de configuration BDD
- ✅ `config/config.php` - Configuration générale
- ✅ `.gitignore` - Pour Git
- ✅ `migration_2fa.sql` - Migration pour bases existantes

## ❌ Ce qui N'est PAS inclus (normal)

### Fichiers exclus automatiquement
- ❌ `vendor/` - Dépendances Composer (500+ MB)
  - **Sera installé avec** `composer install`
- ❌ `config/database.php` - Configuration locale
  - **À créer à partir de** `database.example.php`
- ❌ `.git/` - Historique Git
- ❌ Fichiers de test/debug :
  - `test_2fa.php`
  - `debug_2fa.php`
  - `verify_code.php`
  - `quick_test.php`
  - `export_db.php`
  - `create_release.php`
- ❌ Cache PHPUnit : `.phpunit.cache/`, `coverage/`
- ❌ IDE : `.vscode/`, `.idea/`, `.vs/`
- ❌ Fichiers système : `.DS_Store`, `Thumbs.db`
- ❌ Images uploadées : `public/assets/img/articles/*.jpg` (dossier vide conservé)

## 🚀 Instructions pour le destinataire

### Installation automatique (recommandé)

```
1. Décompresser le ZIP
2. Ouvrir le navigateur : http://localhost/votre-projet/install.php
3. Suivre les étapes à l'écran
```

### Installation manuelle

```bash
# 1. Configurer la base de données
cp config/database.example.php config/database.php
# Éditer database.php avec vos paramètres

# 2. Installer les dépendances
composer install

# 3. Importer la base de données
mysql -u root -p sport_2000 < sport_2000.sql

# 4. Accéder à l'application
http://localhost/votre-projet/public/
```

## 📝 Comptes de test

Une fois installé, utiliser ces comptes :

- **Admin avec 2FA** : raphael.lang@gmail.com / 123
- **User sans 2FA** : jane@example.com / 123

## 🔐 Fonctionnalité 2FA

Le projet inclut l'authentification à deux facteurs :
- Documentation : `README_2FA.md`
- Compatible avec Google Authenticator, Authy, Microsoft Authenticator
- Activation optionnelle par utilisateur

## ⚙️ Régénérer le ZIP

Si vous modifiez le projet et voulez recréer le ZIP :

```bash
# Supprimer l'ancien ZIP
rm STEP5-mvc-poo-composer-v2.0-2FA.zip

# Recréer (cette commande ne marchera pas car le script est exclu)
# Il faut enlever create_release.php du .gitignore temporairement
php create_release.php
```

Ou manuellement :
1. Exclure les dossiers/fichiers listés ci-dessus
2. Créer l'archive ZIP
3. Inclure `config/database.example.php`

## 📊 Statistiques du projet

- **Taille du ZIP** : 240 KB (sans vendor/)
- **Fichiers inclus** : 58
- **Avec vendor/** : ~10 MB (après `composer install`)
- **Version** : 2.0.0 (avec 2FA)

## 🎯 Checklist avant partage

- [x] Base de données exportée avec colonnes 2FA
- [x] `config/database.example.php` créé
- [x] `.gitignore` à jour
- [x] Documentation complète (README, 2FA docs)
- [x] Script d'installation fonctionnel
- [x] Vendor/ exclu
- [x] Fichiers de test exclus
- [x] Configuration locale exclue
- [x] ZIP créé et testé

## 🔧 Support

Pour toute question du destinataire, lui indiquer :
1. Lire `INSTALLATION.txt` dans le ZIP
2. Consulter `README_2FA.md` pour le 2FA
3. Vérifier les prérequis (PHP 8.0+, MySQL, Composer)

---

**Le projet est prêt à être partagé ! 🎉**

Fichier : `STEP5-mvc-poo-composer-v2.0-2FA.zip`
