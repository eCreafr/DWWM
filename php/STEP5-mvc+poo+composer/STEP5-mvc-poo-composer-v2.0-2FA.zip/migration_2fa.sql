-- Migration pour ajouter l'authentification 2FA
-- Ce script ajoute les colonnes nécessaires à la table users pour gérer le 2FA
-- Exécutez ce script si vous mettez à jour un projet existant

USE sport_2000;

-- Ajoute les colonnes 2FA si elles n'existent pas déjà
ALTER TABLE users
ADD COLUMN IF NOT EXISTS two_factor_secret VARCHAR(255) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS two_factor_enabled TINYINT(1) DEFAULT 0;

-- Affiche un message de confirmation
SELECT 'Migration 2FA terminée avec succès!' AS message;
