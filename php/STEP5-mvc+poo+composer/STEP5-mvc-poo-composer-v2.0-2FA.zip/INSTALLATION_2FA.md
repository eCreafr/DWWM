# Guide d'installation - Authentification 2FA

## Résumé de l'implémentation

L'authentification à deux facteurs (2FA) a été **intégrée avec succès** au projet MVC PHP avec les fonctionnalités suivantes :

### Fonctionnalités ajoutées

- Activation/désactivation du 2FA par utilisateur
- Génération de QR codes pour configuration facile
- Vérification des codes OTP compatibles avec Google Authenticator, Authy, Microsoft Authenticator
- Interface utilisateur complète pour la gestion du 2FA
- Protection supplémentaire lors de la connexion

## Fichiers modifiés et ajoutés

### Fichiers modifiés

1. **composer.json** - Ajout de la dépendance `pragmarx/google2fa`
2. **sport_2000.sql** - Ajout des colonnes `two_factor_secret` et `two_factor_enabled`
3. **src/Models/User.php** - Ajout des méthodes de gestion 2FA
4. **src/Controllers/AuthController.php** - Ajout de la logique 2FA lors de la connexion
5. **src/Router.php** - Ajout des nouvelles routes 2FA
6. **src/Views/layouts/default.php** - Ajout du bouton "Sécurité 2FA" dans le menu
7. **install.php** - Mise à jour pour installer la dépendance 2FA

### Fichiers créés

1. **src/Helpers/TwoFactorHelper.php** - Helper pour gérer le 2FA
2. **src/Views/auth/verify-2fa.php** - Page de vérification du code 2FA
3. **src/Views/auth/2fa-settings.php** - Page de gestion du 2FA
4. **migration_2fa.sql** - Script de migration pour bases existantes
5. **README_2FA.md** - Documentation complète du 2FA
6. **test_2fa.php** - Script de test du 2FA
7. **INSTALLATION_2FA.md** - Ce fichier

## Installation pour un nouveau projet

### Étape 1 : Installer les dépendances

```bash
cd /chemin/vers/projet
composer install
```

Cela installera automatiquement :
- `egulias/email-validator` (validation emails)
- `pragmarx/google2fa` (2FA)
- `phpunit/phpunit` (tests)

### Étape 2 : Créer la base de données

```bash
mysql -u root -p < sport_2000.sql
```

Ou utiliser le script d'auto-installation :
```
http://localhost/votre-projet/install.php
```

Le fichier SQL contient déjà les colonnes 2FA.

### Étape 3 : Tester

Lancer le script de test :
```bash
php test_2fa.php
```

Vous devriez voir :
```
=== Test de l'authentification 2FA ===
Test 1 : Génération d'un secret
Secret généré : [SECRET]
Valide : OUI

Test 3 : Vérification du code
Vérification : SUCCÈS ✓
```

## Migration d'un projet existant

Si vous avez déjà une base de données en production :

### Étape 1 : Installer la dépendance

```bash
composer require pragmarx/google2fa
```

### Étape 2 : Migrer la base de données

```bash
mysql -u root -p sport_2000 < migration_2fa.sql
```

### Étape 3 : Copier les fichiers

Assurez-vous que tous les fichiers suivants sont présents :
- `src/Helpers/TwoFactorHelper.php`
- `src/Views/auth/verify-2fa.php`
- `src/Views/auth/2fa-settings.php`

### Étape 4 : Vérifier les modifications

Vérifiez que les fichiers suivants ont été modifiés :
- `src/Models/User.php` (méthodes 2FA)
- `src/Controllers/AuthController.php` (logique 2FA)
- `src/Router.php` (routes 2FA)
- `src/Views/layouts/default.php` (bouton 2FA)

## Vérification de l'installation

### 1. Vérifier Composer

```bash
composer show pragmarx/google2fa
```

Devrait afficher :
```
name     : pragmarx/google2fa
versions : * v9.0.0
```

### 2. Vérifier la base de données

```sql
DESCRIBE users;
```

Devrait contenir :
```
two_factor_secret   | varchar(255) | YES  |     | NULL
two_factor_enabled  | tinyint(1)   | YES  |     | 0
```

### 3. Tester le Helper

```bash
php test_2fa.php
```

Tous les tests doivent passer avec succès.

### 4. Tester l'interface

1. Se connecter à l'application
2. Cliquer sur "Sécurité 2FA" dans le menu
3. Scanner le QR code avec Google Authenticator
4. Entrer le code à 6 chiffres
5. Activer le 2FA

## Routes disponibles

| Route | Description | Méthode |
|-------|-------------|---------|
| `/2fa-settings.html` | Page de gestion 2FA | GET |
| `/enable-2fa.html` | Activer le 2FA | POST |
| `/disable-2fa.html` | Désactiver le 2FA | POST |
| `/verify-2fa.html` | Page de vérification 2FA | GET |
| `/verify-2fa-post.html` | Vérifier le code 2FA | POST |

## Structure de la base de données

### Table `users` - Colonnes 2FA

```sql
two_factor_secret VARCHAR(255) DEFAULT NULL
  - Stocke la clé secrète 2FA (32 caractères base32)
  - NULL si le 2FA n'est pas configuré

two_factor_enabled TINYINT(1) DEFAULT 0
  - 0 = 2FA désactivé
  - 1 = 2FA activé
```

## Flux de connexion avec 2FA

```
1. Utilisateur entre email/password
   ↓
2. AuthController::login() vérifie les identifiants
   ↓
3. Si two_factor_enabled = 1
   ├─ Stocke données dans $_SESSION['pending_2fa_user']
   └─ Redirige vers verify-2fa.html
   ↓
4. Utilisateur entre le code 2FA
   ↓
5. AuthController::verify2FA() vérifie le code
   ↓
6. Si code valide
   ├─ Crée $_SESSION['user']
   ├─ Supprime $_SESSION['pending_2fa_user']
   └─ Redirige vers home.html
```

## Dépannage

### Erreur : Class 'PragmaRX\Google2FA\Google2FA' not found

**Solution** : Installer les dépendances
```bash
composer install
```

### Erreur : Unknown column 'two_factor_secret'

**Solution** : Exécuter la migration
```bash
mysql -u root -p sport_2000 < migration_2fa.sql
```

### Le code 2FA ne fonctionne jamais

**Causes possibles** :
- Heure du serveur non synchronisée
- Heure du téléphone non synchronisée
- Code expiré (change toutes les 30 secondes)

**Solution** : Vérifier la synchronisation horaire

### Le QR code ne s'affiche pas

**Cause** : L'application utilise l'API externe qrserver.com

**Solutions** :
- Vérifier la connexion Internet
- Copier manuellement la clé secrète dans l'application

## Compatibilité

### Applications d'authentification testées

- Google Authenticator (Android/iOS)
- Microsoft Authenticator (Android/iOS)
- Authy (Android/iOS/Desktop)
- 1Password (Multi-plateforme)

### Prérequis techniques

- PHP >= 8.0
- MySQL/MariaDB
- Extension PDO
- Composer

## Sécurité

### Points forts

- Secrets stockés en base de données (jamais en clair dans le code)
- Validation stricte des codes (fenêtre de ±30 secondes)
- Session temporaire pour l'authentification 2FA
- Tous les formulaires utilisent POST
- Codes OTP à usage unique (TOTP)

### Points d'amélioration possibles

- Ajouter des codes de secours
- Implémenter un rate limiting sur les tentatives
- Logger les activations/désactivations du 2FA
- Notifier par email lors des changements 2FA
- Générer les QR codes localement (sans API externe)

## Support et documentation

### Fichiers de documentation

- `README_2FA.md` - Documentation détaillée du 2FA
- `INSTALLATION_2FA.md` - Ce guide d'installation
- `migration_2fa.sql` - Script de migration SQL

### Ressources externes

- Documentation PragmaRX Google2FA : https://github.com/antonioribeiro/google2fa
- RFC 6238 (TOTP) : https://tools.ietf.org/html/rfc6238
- Google Authenticator : https://support.google.com/accounts/answer/1066447

## Test de validation finale

Utilisez cette checklist pour valider l'installation :

- [ ] `composer show pragmarx/google2fa` affiche la version 9.0.0
- [ ] La table `users` contient les colonnes `two_factor_secret` et `two_factor_enabled`
- [ ] `php test_2fa.php` réussit tous les tests
- [ ] La page `/2fa-settings.html` est accessible après connexion
- [ ] Le QR code s'affiche correctement
- [ ] Scanner le QR code avec Google Authenticator fonctionne
- [ ] La vérification du code 2FA fonctionne
- [ ] La connexion avec 2FA activé fonctionne
- [ ] La désactivation du 2FA fonctionne

## Félicitations !

Si tous les tests passent, votre projet dispose maintenant d'une **authentification à deux facteurs complète et fonctionnelle** ! 🎉

Les utilisateurs peuvent maintenant sécuriser leurs comptes avec une couche de protection supplémentaire.
