# Changelog - Ajout de l'authentification 2FA

## Version 2.0.0 - 2025-12-17

### Ajout majeur : Authentification à deux facteurs (2FA)

L'authentification à deux facteurs a été intégrée au projet pour renforcer la sécurité.

---

## Modifications détaillées

### 📦 Dépendances Composer

#### Ajouts
- **pragmarx/google2fa** (^9.0) - Bibliothèque pour TOTP (Time-based One-Time Password)
- **paragonie/constant_time_encoding** (^3.1.3) - Dépendance de google2fa

#### Fichier modifié
- `composer.json` - Ajout de `pragmarx/google2fa: ^9.0` dans `require`

---

### 🗄️ Base de données

#### Modifications de la table `users`

Ajout de deux colonnes :

```sql
two_factor_secret VARCHAR(255) DEFAULT NULL
  - Stocke la clé secrète 2FA (base32, 32 caractères)
  - NULL si 2FA non configuré

two_factor_enabled TINYINT(1) DEFAULT 0
  - 0 = 2FA désactivé
  - 1 = 2FA activé
```

#### Fichiers modifiés
- `sport_2000.sql` (lignes 155-165) - Ajout des colonnes dans CREATE TABLE

#### Fichiers créés
- `migration_2fa.sql` - Script de migration pour bases existantes

---

### 🛠️ Helpers

#### Nouveau fichier : `src/Helpers/TwoFactorHelper.php`

Classe utilitaire pour gérer l'authentification 2FA.

**Méthodes statiques** :
- `generateSecret()` - Génère un secret 2FA
- `getQRCodeUrl($email, $secret, $appName)` - Génère l'URL pour QR code
- `getQRCodeInline($email, $secret, $appName)` - Génère l'URL d'image QR code
- `verifyCode($secret, $code, $window)` - Vérifie un code OTP
- `getCurrentCode($secret)` - Obtient le code actuel (pour tests)
- `isValidSecret($secret)` - Vérifie la validité d'un secret

---

### 📝 Modèles

#### Fichier modifié : `src/Models/User.php`

**Modification** :
- `getByEmail()` (ligne 87) - Ajout de `two_factor_secret, two_factor_enabled` dans le SELECT

**Ajouts** (lignes 222-287) :
- `enableTwoFactor($userId, $secret)` - Active le 2FA
- `disableTwoFactor($userId)` - Désactive le 2FA
- `hasTwoFactorEnabled($userId)` - Vérifie si 2FA activé
- `getTwoFactorSecret($userId)` - Récupère le secret 2FA

---

### 🎮 Contrôleurs

#### Fichier modifié : `src/Controllers/AuthController.php`

**Import ajouté** (ligne 7) :
```php
use App\Helpers\TwoFactorHelper;
```

**Modification de `login()`** (lignes 101-133) :
- Vérifie si l'utilisateur a le 2FA activé
- Si oui : stocke données dans `$_SESSION['pending_2fa_user']` et redirige vers vérification
- Si non : connexion normale

**Nouvelles méthodes** (lignes 161-326) :
- `showVerify2FA()` - Affiche formulaire vérification 2FA
- `verify2FA()` - Traite la vérification du code 2FA
- `show2FASettings()` - Page de gestion 2FA
- `enable2FA()` - Active le 2FA après vérification du code
- `disable2FA()` - Désactive le 2FA

---

### 🚦 Routage

#### Fichier modifié : `src/Router.php`

**Pages autorisées ajoutées** (lignes 103-107) :
```php
'verify-2fa',
'verify-2fa-post',
'2fa-settings',
'enable-2fa',
'disable-2fa',
```

**Routes ajoutées** (lignes 184-207) :
- `verify-2fa` → `AuthController::showVerify2FA()`
- `verify-2fa-post` → `AuthController::verify2FA()`
- `2fa-settings` → `AuthController::show2FASettings()`
- `enable-2fa` → `AuthController::enable2FA()`
- `disable-2fa` → `AuthController::disable2FA()`

---

### 🎨 Vues

#### Nouveau fichier : `src/Views/auth/verify-2fa.php`

Interface de vérification du code 2FA lors de la connexion.

**Caractéristiques** :
- Champ de saisie du code à 6 chiffres
- Validation JavaScript (supprime caractères non-numériques)
- Design centré avec Bootstrap
- Bouton "Annuler" pour retourner à la connexion

#### Nouveau fichier : `src/Views/auth/2fa-settings.php`

Interface de gestion du 2FA (activation/désactivation).

**Fonctionnalités** :
- Affichage du QR code pour configuration
- Affichage de la clé secrète avec bouton "Copier"
- Formulaire de vérification pour activer le 2FA
- Bouton de désactivation du 2FA
- Liste des applications d'authentification recommandées
- Instructions étape par étape

#### Fichier modifié : `src/Views/layouts/default.php`

**Ajout** (lignes 37-42) :
```php
<a href="<?= BASE_URL ?>/2fa-settings.html"
    class="btn btn-sm btn-outline-secondary rounded-pill"
    title="Authentification 2FA">
    Sécurité 2FA
</a>
```

Bouton "Sécurité 2FA" visible uniquement pour les utilisateurs connectés.

---

### 🔧 Scripts d'installation

#### Fichier modifié : `install.php`

**Modification** (ligne 181) :
- Ajout de `pragmarx/google2fa (2FA)` dans la liste des dépendances installées

---

### 📚 Documentation

#### Nouveaux fichiers créés

1. **README_2FA.md**
   - Documentation complète du système 2FA
   - Vue d'ensemble de l'architecture
   - Guide d'utilisation pour développeurs et utilisateurs
   - Exemples de code
   - Sécurité et bonnes pratiques
   - Dépannage

2. **INSTALLATION_2FA.md**
   - Guide d'installation pas à pas
   - Instructions pour nouveau projet
   - Instructions pour migration projet existant
   - Checklist de validation
   - Dépannage

3. **CHANGELOG_2FA.md** (ce fichier)
   - Liste exhaustive de toutes les modifications

4. **test_2fa.php**
   - Script de test automatique du 2FA
   - Vérifie génération de secrets
   - Vérifie génération et validation de codes
   - Vérifie génération de QR codes

---

## 🔒 Flux d'authentification 2FA

### Avant (sans 2FA)
```
Login → Vérification email/password → Session créée → Accueil
```

### Après (avec 2FA activé)
```
Login → Vérification email/password → Vérification code 2FA → Session créée → Accueil
```

### Session temporaire
```
$_SESSION['pending_2fa_user'] = [
    'id' => ...,
    'name' => ...,
    'email' => ...,
    'role' => ...,
    'two_factor_secret' => ...
]
```

Cette session temporaire est supprimée après vérification réussie du code.

---

## 📊 Statistiques

### Fichiers modifiés : 7
- composer.json
- sport_2000.sql
- src/Models/User.php
- src/Controllers/AuthController.php
- src/Router.php
- src/Views/layouts/default.php
- install.php

### Fichiers créés : 7
- src/Helpers/TwoFactorHelper.php
- src/Views/auth/verify-2fa.php
- src/Views/auth/2fa-settings.php
- migration_2fa.sql
- README_2FA.md
- INSTALLATION_2FA.md
- test_2fa.php

### Nouvelles méthodes : 9
- TwoFactorHelper : 6 méthodes
- User : 4 méthodes
- AuthController : 5 méthodes

### Nouvelles routes : 5
- verify-2fa.html
- verify-2fa-post.html
- 2fa-settings.html
- enable-2fa.html
- disable-2fa.html

---

## ✅ Tests

### Script de test automatique

Le fichier `test_2fa.php` effectue les tests suivants :

1. ✅ Génération d'un secret valide (32 caractères base32)
2. ✅ Génération d'un code OTP à 6 chiffres
3. ✅ Vérification d'un code valide (retourne true)
4. ✅ Rejet d'un code invalide (retourne false)
5. ✅ Génération d'URL de QR code

**Commande** :
```bash
php test_2fa.php
```

---

## 🔐 Sécurité

### Améliorations de sécurité

1. **Double authentification** - Même si le mot de passe est compromis, l'attaquant ne peut pas se connecter sans le code 2FA
2. **Codes temporaires** - Les codes OTP changent toutes les 30 secondes
3. **Validation stricte** - Fenêtre de tolérance de ±30 secondes uniquement
4. **Session séparée** - Les données 2FA sont dans une session temporaire distincte
5. **Protection POST** - Toutes les actions 2FA utilisent des formulaires POST

### Points d'attention

- ⚠️ Pas de codes de secours (prévu pour version future)
- ⚠️ Pas de rate limiting sur tentatives (prévu pour version future)
- ⚠️ QR codes générés via API externe (envisager solution locale)

---

## 🚀 Déploiement

### Pour une nouvelle installation

1. Cloner le projet
2. `composer install` (installe automatiquement pragmarx/google2fa)
3. Importer `sport_2000.sql` (contient déjà les colonnes 2FA)
4. Accéder à l'application

### Pour une mise à jour d'une installation existante

1. `git pull` (récupérer les modifications)
2. `composer install` (installer google2fa)
3. Exécuter `migration_2fa.sql` sur la base de données
4. Tester avec `php test_2fa.php`

---

## 📱 Applications compatibles

Le système 2FA est compatible avec toutes les applications TOTP standard :

- Google Authenticator (Android/iOS)
- Microsoft Authenticator (Android/iOS)
- Authy (Android/iOS/Desktop)
- 1Password (payant, multi-plateforme)
- FreeOTP (Android/iOS)
- AndOTP (Android)

---

## 🎯 Objectifs atteints

- ✅ Intégration complète du 2FA via Composer
- ✅ Interface utilisateur intuitive
- ✅ Compatibilité avec applications standards
- ✅ Documentation exhaustive
- ✅ Script de test automatique
- ✅ Migration facile pour projets existants
- ✅ Script d'installation mis à jour
- ✅ Aucune régression sur fonctionnalités existantes

---

## 🔮 Améliorations futures possibles

1. **Codes de secours** - Générer 10 codes de secours à usage unique
2. **Rate limiting** - Limiter tentatives de code 2FA (3 essais par 5 minutes)
3. **QR code local** - Utiliser une bibliothèque PHP pour générer QR codes
4. **Notifications email** - Alerter l'utilisateur lors d'activation/désactivation
5. **Historique** - Logger les connexions avec 2FA
6. **2FA obligatoire** - Option pour forcer 2FA pour tous les admins
7. **Application mobile** - Développer une app dédiée

---

## 👨‍💻 Développeur

Implémentation réalisée le 17 décembre 2025 par Claude (Anthropic).

## 📞 Support

Pour toute question :
- Consulter `README_2FA.md`
- Consulter `INSTALLATION_2FA.md`
- Consulter la documentation PragmaRX : https://github.com/antonioribeiro/google2fa
