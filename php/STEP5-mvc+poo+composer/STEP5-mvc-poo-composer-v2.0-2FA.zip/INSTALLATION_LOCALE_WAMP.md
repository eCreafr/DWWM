# Installation Locale sur WAMP

## 🎓 Pour les Stagiaires

### Problème Connu : Apache/WAMP et Processus Longs

Sur **WAMP/XAMPP** en local, Apache a une limitation connue qui empêche l'exécution de `composer install` via l'interface web pendant de longues périodes.

**Erreur typique** :
```
AH02965: Child: Unable to retrieve my generation from the parent
```

**Note** : Ce problème **n'existe PAS sur les serveurs de production** (OVH, Linux, etc.). C'est spécifique à WAMP/Windows.

---

## ✅ Solution pour Démo Locale

### Méthode 1 : Installation Préalable de Composer (Recommandée)

**Étape 1** : Installer les dépendances Composer en ligne de commande

```bash
# Ouvrir un terminal (PowerShell ou CMD)
cd C:\wamp64\www\votre-projet

# Installer les dépendances
php composer.phar install
```

**Étape 2** : Lancer install.php via navigateur

```
http://localhost/votre-projet/install.php
```

**Résultat** :
- ✅ Détecte que `vendor/` existe déjà
- ✅ Saute l'installation Composer
- ✅ Importe la base de données
- ✅ Lance les tests PHPUnit
- ✅ Installation terminée !

**Logs attendus** :
```
📦 Installation des dépendances Composer...
✓ Dossier vendor/ déjà présent
✅ Dépendances Composer déjà installées !
   - egulias/email-validator
   - pragmarx/google2fa (2FA)
ℹ️  Installation Composer ignorée (vendor/ existe)

💾 Import de la base de données...
✅ Base de données 'sport_2000' créée/vérifiée
...
```

---

### Méthode 2 : Démo Complète sur OVH (Recommandée pour Formation)

Pour montrer le **processus DevOps complet** sans aucune intervention manuelle :

1. **Uploadez le ZIP sur OVH**
2. **Décompressez**
3. **Lancez install.php**
4. **Tout s'installe automatiquement** ! 🎉

**Sur OVH** :
- ✅ Composer s'installe automatiquement
- ✅ Base de données importée
- ✅ Tests exécutés
- ✅ 100% autonome

---

## 🎯 Approche Pédagogique

### Ce que Vos Stagiaires Apprendront

**En Local (WAMP)** :
1. ✅ Installation manuelle de Composer (ligne de commande)
2. ✅ Compréhension de `vendor/` et de l'autoload
3. ✅ Script d'installation intelligent (détecte vendor/ existant)
4. ✅ Import automatique de la base de données
5. ✅ Exécution des tests PHPUnit
6. ✅ Limitations de l'environnement local vs production

**En Production (OVH)** :
1. ✅ Déploiement automatique complet
2. ✅ Installation zero-touch
3. ✅ DevOps moderne (CI/CD simplifié)
4. ✅ Pas de limitations serveur

---

## 📝 Script de Démo pour Formation

### Scénario 1 : Installation Locale

**Ce que vous dites** :
> "Sur notre machine de développement, nous avons WAMP qui a certaines limitations pour les processus longs.
> Nous allons donc installer Composer manuellement, puis laisser le script faire le reste."

**Commandes** :
```bash
cd C:\wamp64\www\projet-sport2000
php composer.phar install
```

**Puis dans le navigateur** :
```
http://localhost/projet-sport2000/install.php
```

**Résultat** : Script détecte vendor/, importe BDD, lance tests → Succès !

---

### Scénario 2 : Déploiement Production (OVH)

**Ce que vous dites** :
> "Maintenant, voyons comment le même projet se déploie en production, où tout est automatisé de A à Z."

**Actions** :
1. Upload ZIP sur OVH
2. Décompression
3. Accès à install.php
4. **Magie** : Tout s'installe seul !

**Résultat** : Installation 100% automatique, aucune intervention.

---

## 🔍 Comparaison Local vs Production

| Étape | Local (WAMP) | Production (OVH) |
|-------|--------------|------------------|
| **Upload fichiers** | Copier dans www/ | FTP vers serveur |
| **Composer install** | ⚠️ Ligne de commande | ✅ Automatique |
| **Base de données** | ✅ Automatique (install.php) | ✅ Automatique |
| **Tests PHPUnit** | ✅ Automatique | ⚠️ Optionnel (--no-dev) |
| **Configuration** | ✅ Interface web | ✅ Interface web |

**Conclusion** : En production, **0 intervention manuelle** !

---

## 💡 Points Pédagogiques à Souligner

### 1. Différences Dev vs Prod
- Environnement local : Outils de développement, limitations Apache
- Production : Optimisé pour l'exécution, pas de limitations

### 2. Intelligence du Script
```php
// Le script détecte si vendor/ existe
if (is_dir($vendorPath) && file_exists($vendorPath . '/autoload.php')) {
    // Skip Composer installation
}
```
→ Évite les réinstallations inutiles

### 3. DevOps Modern
- **IaC (Infrastructure as Code)** : Tout est scriptable
- **Idempotence** : Peut être relancé plusieurs fois sans casser
- **Zero-touch deployment** : En production, aucune intervention

### 4. Résolution de Problèmes
- Identification du problème (logs Apache)
- Adaptation de la solution (détection vendor/)
- Alternative fonctionnelle (ligne de commande)

---

## 🚀 Workflow Complet de Démo

### Phase 1 : Développement Local (5 min)

1. **Montrer la structure** du projet
   ```bash
   ls -la
   # composer.phar, src/, public/, install.php, etc.
   ```

2. **Installer Composer** manuellement
   ```bash
   php composer.phar install
   ```
   → Expliquer ce que fait Composer (autoload, dépendances)

3. **Lancer install.php**
   → Montrer qu'il détecte vendor/, importe BDD, lance tests

4. **Tester le site**
   ```
   http://localhost/projet/public/
   ```

---

### Phase 2 : Déploiement Production (10 min)

1. **Préparer le ZIP** (déjà fait)
   ```bash
   # Montrer le contenu
   unzip -l STEP5-mvc-poo-composer-v2.0-2FA.zip
   ```

2. **Upload sur OVH** via FTP
   → Expliquer le transfert de fichiers

3. **Décompression** sur le serveur
   → Via gestionnaire de fichiers OVH

4. **Accès à install.php**
   ```
   https://votre-domaine.com/projet/install.php
   ```

5. **Observer l'installation automatique**
   → Tout se fait sans intervention !

6. **Tester le site en production**
   ```
   https://votre-domaine.com/projet/public/
   ```

---

### Phase 3 : Comparaison et Apprentissage (5 min)

**Questions aux stagiaires** :
- Quelle différence avez-vous vu entre local et production ?
- Pourquoi Composer fonctionne automatiquement sur OVH mais pas sur WAMP ?
- Qu'est-ce qui rend ce déploiement "DevOps" ?

**Réponses attendues** :
- Local : Développement, limitations, interventions manuelles OK
- Production : Automatisé, fiable, reproductible
- DevOps : Scriptable, testable, déployable sans intervention

---

## 📋 Checklist pour la Formation

### Préparation
- [ ] WAMP installé et fonctionnel
- [ ] Projet décompressé dans `C:\wamp64\www\`
- [ ] Terminal ouvert (PowerShell/CMD)
- [ ] Navigateur sur `http://localhost/`
- [ ] Accès OVH configuré
- [ ] FileZilla/FTP configuré

### Démo Locale
- [ ] `cd` vers le dossier projet
- [ ] Exécuter `php composer.phar install`
- [ ] Montrer le dossier `vendor/` créé
- [ ] Lancer `install.php` dans le navigateur
- [ ] Observer la détection de `vendor/`
- [ ] Vérifier import BDD réussi
- [ ] Tester le site fonctionnel

### Démo Production
- [ ] Upload ZIP sur OVH
- [ ] Décompression
- [ ] Accès à `install.php`
- [ ] Observer installation automatique complète
- [ ] Tester site production

### Conclusion
- [ ] Comparer les deux approches
- [ ] Expliquer DevOps et CI/CD
- [ ] Questions/Réponses

---

## ✅ Avantages de Cette Approche

### Pour Vous (Formateur)
- ✅ Démo rapide et fiable
- ✅ Montre les vraies différences dev/prod
- ✅ Enseigne troubleshooting et adaptation
- ✅ Installation OVH 100% automatique (effet "wow")

### Pour les Stagiaires
- ✅ Voient tout le cycle : dev → build → deploy
- ✅ Comprennent Composer et dépendances
- ✅ Apprennent les limites des env. locaux
- ✅ Découvrent le vrai DevOps en prod
- ✅ Pratiquent ligne de commande + interface web

---

## 🎉 Conclusion

**Le script install.php reste un excellent outil pédagogique** qui montre :
- Automatisation intelligente (détection vendor/)
- Gestion multi-environnements (dev/prod)
- DevOps moderne (zero-touch en production)
- Troubleshooting réel (limitation WAMP)

**Message clé** :
> En développement local, on peut avoir besoin d'interventions manuelles (limitations techniques).
> En production, tout doit être automatique et reproductible. C'est ça, le DevOps !

---

**Bon courage pour votre formation ! 🚀**
